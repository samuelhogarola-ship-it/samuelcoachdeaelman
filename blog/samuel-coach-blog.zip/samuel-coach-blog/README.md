# Samuel Coach Blog

Tema WordPress personalizado para replicar el blog de `samuelcoachdealeman.com/blog` con una estética y estructura muy cercanas al sitio actual.

## Qué incluye

- Barra superior con ubicación y teléfono.
- Cabecera con logotipo centrado.
- Menú principal responsive con desplegables.
- Portada del blog con hero, título `Mi Blog` y tarjetas de entradas.
- Plantilla individual para posts y plantilla para páginas.
- Pie de página con enlaces y aviso de cookies visual.
- Importador de entradas desde el feed JSON actual.

## Instalación

1. Copia la carpeta `samuel-coach-blog` a `wp-content/themes/` dentro de tu WordPress.
2. Activa el tema desde `Apariencia > Temas`.
3. Ajusta el logo, textos y contacto en `Apariencia > Personalizar`.
4. Si quieres conservar la navegación del sitio actual, crea el menú y asígnalo a `Menú principal`.
5. Ve a `Apariencia > Importar blog externo` para importar las entradas del feed.

## Notas sobre la importación

- URL por defecto del feed: `https://samuelcoachdealeman.com/blog/f.json`
- El importador crea o actualiza posts por ID externo.
- Guarda la URL original de cada entrada como metadato `_scb_source_url`.
- Si el feed solo trae extractos, las entradas importadas quedarán como una primera migración y conviene revisar luego el contenido final.

## Ajustes recomendados en WordPress

- En `Ajustes > Lectura`, usa una página de entradas o la portada del blog según tu estructura.
- Enlaces permanentes: nombre de la entrada.
- Sube el logo actual en formato PNG para acercarte más al aspecto original.
- Si usas un plugin de newsletter, pega su shortcode en el personalizador.
