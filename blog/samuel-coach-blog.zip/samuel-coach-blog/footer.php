<?php
/**
 * Theme footer.
 *
 * @package SamuelCoachBlog
 */

if (! defined('ABSPATH')) {
	exit;
}
?>
	</main>

	<footer class="scb-site-footer">
		<div class="scb-container">
			<hr class="scb-site-footer__rule">
			<div class="scb-site-footer__copy">
				Copyright &copy; <?php echo esc_html(wp_date('Y')); ?> <?php bloginfo('name'); ?> - Todos los derechos reservados.
			</div>
			<?php scb_footer_navigation(); ?>
			<div class="scb-site-footer__powered">
				<?php echo esc_html(scb_get_theme_mod('footer_powered_text')); ?>
			</div>
		</div>
	</footer>

	<div class="scb-cookie" id="scb-cookie-banner" hidden>
		<h2 class="scb-cookie__title">Este sitio web utiliza cookies</h2>
		<p>Usamos cookies para analizar el tráfico del sitio web y optimizar tu experiencia en el sitio. Al aceptar nuestro uso de cookies, tus datos se agruparán con los datos de todos los demás usuarios.</p>
		<div class="scb-cookie__actions">
			<button class="scb-cookie__button" type="button" data-cookie-action="decline">Rechazar</button>
			<button class="scb-cookie__button scb-cookie__button--accept" type="button" data-cookie-action="accept">Aceptar</button>
		</div>
	</div>
</div>
<?php wp_footer(); ?>
</body>
</html>

