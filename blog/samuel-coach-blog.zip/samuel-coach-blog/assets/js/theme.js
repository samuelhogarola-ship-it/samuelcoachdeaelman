document.addEventListener("DOMContentLoaded", function () {
  var toggle = document.querySelector(".scb-menu-toggle");
  var nav = document.querySelector(".scb-primary-nav");

  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("is-open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  var cookieBanner = document.getElementById("scb-cookie-banner");
  var cookieKey = "scb-cookie-consent";

  if (cookieBanner) {
    try {
      if (!window.localStorage.getItem(cookieKey)) {
        cookieBanner.hidden = false;
      }
    } catch (error) {
      cookieBanner.hidden = false;
    }

    cookieBanner.addEventListener("click", function (event) {
      var button = event.target.closest("[data-cookie-action]");
      if (!button) {
        return;
      }

      try {
        window.localStorage.setItem(cookieKey, button.getAttribute("data-cookie-action"));
      } catch (error) {
        // Ignore storage errors and just hide the banner.
      }

      cookieBanner.hidden = true;
    });
  }
});

